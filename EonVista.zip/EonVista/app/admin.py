from django.contrib import admin
from .models import addPost, addComment

admin.site.register(addPost)
admin.site.register(addComment)